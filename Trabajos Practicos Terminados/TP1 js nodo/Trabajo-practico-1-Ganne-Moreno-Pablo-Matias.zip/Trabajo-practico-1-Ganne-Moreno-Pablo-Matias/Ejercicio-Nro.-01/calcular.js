/*
Realizar un programa que permita el Ingreso de 2 (dos números) (A y B) utilizando variables y realice las 
siguientes operaciones.

Muestre la suma de ambos (A + B) 
Muestre la resta (A – B) 
Muestre el Producto de ambos (A * B) 
Muestre el Cociente entre ambos (A / B) 
*/

let numero1 = 0;
let numero2 = 0;
let suma = 0, resta = 0, producto = 0, cociente = 0;

numero1 = Number(prompt("Ingrese el valor de A"));
numero2 = Number(prompt("Ingrese el valor de B"));

suma = (numero1 + numero2);
resta = (numero1 - numero2);
producto = (numero1 * numero2);


if (numero2 == 0) {
    console.log("No se puede dividir por 0");
}
else {
    cociente = (numero1 / numero2);
}

console.log(`suma:${suma}\nresta:${resta}\nproducto:${producto}\ncociente: ${numero2 ? cociente: 'error match' }\n`);