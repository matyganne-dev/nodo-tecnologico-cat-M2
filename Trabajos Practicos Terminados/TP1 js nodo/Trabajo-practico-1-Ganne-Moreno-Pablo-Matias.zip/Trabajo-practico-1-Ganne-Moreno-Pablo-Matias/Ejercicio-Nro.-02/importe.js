/*Realizar un programa que permita ingresar el importe total de una compra que realiza un cliente y sobre 
el mismo aplicarle un descuento del 15%. Mostrar por consola el importe total de la compra y el descuento del 
15% como así también el importe restante final.*/


let importeTotal = 0;
let importe = 0;
let descuento = 15;


importeTotal = Number(prompt("Ingrese su importe total"));
importe = importeTotal - (importeTotal * (descuento / 100));


console.log(`El Importe total:${importeTotal}\nDescuento aplicado:${descuento}\n Importe restante final: ${importe}`);