/*realizar un programa que permita ingresar los totales que una persona pagó por sus servicios en su hogar. 
El primer valor representará los gastos de energía (luz eléctrica), el segundo valor representará los gastos en 
comunicación (conectividad a internet), el tercer valor representará los gastos ocasionados por el servicio de agua 
potable. Se estima que para el siguiente mes estos tres valores incrementarán en un 12,5%, 7% y 3% 
respectivamente. El programa debe calcular el gasto futuro a pagar. */

let gastoDeluz = 0;
let gastoDeComunicacion = 0;
let gastoDeAgua = 0;

gastoDeluz = Number(prompt("Ingrese gasto de luz"));
gastoDeComunicacion = Number(prompt("Ingrese gasto de internet"));
gastoDeAgua = Number(prompt("Ingrese gasto de Agua potable"));

console.log("Gastos estimados para el siguiente mes:");

gastoDeluz = (gastoDeluz * 0.125) + gastoDeluz;
gastoDeComunicacion = (gastoDeComunicacion * 0.07) + gastoDeComunicacion;
gastoDeAgua = (gastoDeAgua * 0.03) + gastoDeAgua;

console.log(` Gasto de luz:$${gastoDeluz.toFixed(2)}\n Gasto de internet:$${gastoDeComunicacion.toFixed(2)}\n Gasto de Agua potable:$${gastoDeAgua.toFixed(2)}`);