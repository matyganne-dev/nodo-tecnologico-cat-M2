/*Ingrese un número y determine si es positivo o negativo usando una estructura condicional if/else y 
también resuelva el mismo problema utilizando un operador ternario. */


let numero = 0;
let resultado;

numero = Number(prompt("Ingrese un numero"));

//condicional if/else
// if(numero >= 0){
//     console.log(`El numero ${numero} es positivo`);
// }
// else{
//     console.log(`El numero ${numero} es negativo`);
// }


//condicional con operador ternario
resultado = numero >= 0 ? "positivo" : "negativo";

console.log(`--El numero ${numero} es ${resultado}--`);