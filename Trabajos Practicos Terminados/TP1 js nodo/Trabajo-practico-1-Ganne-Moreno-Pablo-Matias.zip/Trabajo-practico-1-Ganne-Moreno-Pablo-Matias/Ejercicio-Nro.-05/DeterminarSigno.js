/*Realizar un programa que permita introducir un valor (X) y determinar si el mismo es PAR ó IMPAR. */


let valor = 0;

valor = Number(prompt("Ingresa un valor"));

if(valor%2 == 0){
    console.log(`el valor:${valor} es par`);
}
else{
    console.log(`el valor:${valor} es impar`);
}
