/*Banco Nación de la República Argentina, tiene una promoción muy importante para sus clientes 
denominada “one shot” que consta en realizar un importante de descuento del 50% en las compras del cliente, 
teniendo en cuenta que el descuento máximo a otorgar (descuento tope) es equivalente a 80.000,00 (ochenta mil 
pesos argentinos). 
Realice un programa que permita introducir el valor de la compra y calcular el porcentaje de descuento 
sabiendo que no se puede pasar el límite establecido. */

let descuento = 50;
let topeDescuento = 80000;
let importe = 0;
let importeConDescuento = 0;
let resultado = 0;

importe = Number(prompt("Ingresar el monto gastado"));
importeConDescuento = (importe * descuento) / 100;


if (importeConDescuento >= topeDescuento) {
    resultado =  importe - 80000;
    console.log(`el resultado es $${resultado}`);
} 
else {
    resultado =   importe - importeConDescuento;
    console.log(`el resultado es $${resultado}`);
}


