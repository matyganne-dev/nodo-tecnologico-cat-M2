/*
Un comercio que vende bolsas de alimentos para mascotas trabaja y comercializa únicamente con tres 
grandes marcas de alimentos para perros lo que le permite trabajar con descuentos muy interesantes para sus 
clientes. Las marcas con las que trabaja son:

Realice un programa en JavaScript que permita ingresar el código del producto y la cantidad de bolsas a 
comprar y que solo determine el importe total a pagar. 
*/

let cantidad = 0;
let codigo = 0;
let valor = 0;

codigo = Number(prompt(`Catalogo de productos:\n Elige una de las opciones para comprar \n 1- Dogui x 21 kg\n 2- Tiernitos x 21 Kg\n 3- Dogpro x 21 kg`));


switch (codigo) {
    case 1: {
        let importe = 0;
        cantidad = Number(prompt("Ingrese la cantidad a comprar de Dogui x 21 kg\n precio por unidad: $38.000,00"));

        if (cantidad >= 1 && cantidad < 5) {
            valor = 38000;
            importe = cantidad * valor;
            console.log(`Importe total: $${importe}`);
        }
        else if ((cantidad >= 5) && (cantidad <= 10)) {
            valor = 36000;
            importe = cantidad * valor;
            console.log(`Importe total: $${importe}`);
        }
        else {
            valor = 34000;
            importe = cantidad * valor;
            console.log(`Importe total: $${importe}`);
        }
        break;
    }
    case 2: {
        let importe = 0;
        cantidad = Number(prompt("Ingrese la cantidad a comprar de Tiernitos x 21 Kg\n precio por unidad: $31.000,00"));
        if (cantidad >= 1 && cantidad < 5) {
            valor = 31000;
            importe = cantidad * valor;
            console.log(`Importe total: $${importe}`);
        }
        else if ((cantidad >= 5) && (cantidad <= 10)) {
            valor = 29000;
            importe = cantidad * valor;
            console.log(`Importe total: $${importe}`);
        }
        else {
            valor = 27000;
            importe = cantidad * valor;
            console.log(`Importe total: $${importe}`);
        }
        break;
    }
    case 3: {
        let importe = 0;
        cantidad = Number(prompt("Ingrese la cantidad a comprar de Dogpro x 21 kg\n precio por unidad: $46.000,00"));

        if (cantidad >= 1 && cantidad < 5) {
            valor = 46000;
            importe = cantidad * valor;
            console.log(`Importe total: $${importe}`);
        }
        else if ((cantidad >= 5) && (cantidad <= 10)) {
            valor = 44000;
            importe = cantidad * valor;
            console.log(`Importe total: $${importe}`);
        }
        else {
            valor = 42000;
            importe = cantidad * valor;
            console.log(`Importe total: $${importe}`);
        }
        break;
    }
    default: {
        console.log("opcion no valida");
    }
}

