/* Realizar un programa que permita ingresar la edad de una persona y determine si es niño (0 a 12 años), 
adolescente (13 a 17 años), adulto (18 a 64 años), adulto mayor (más de 64 años).*/


let edad = 0;

edad = Number(prompt("Ingrese la edad"));


if (edad > 0 && edad<13){
    console.log(`esta persona tiene una edad de ${edad}, es un niño`);
}
else if(edad >= 13 && edad <18){
    console.log(`esta persona tiene una edad de ${edad}, es un adolescente`);
}
else if(edad >= 18 && edad <64){
    console.log(`esta persona tiene una edad de ${edad}, es un adulto`);
}
else if(edad>=64){
    console.log(`esta persona tiene una edad de ${edad}, es un adulto mayor`);
}
else{
    console.log(`esta edad ${edad}, no es valida`);
}